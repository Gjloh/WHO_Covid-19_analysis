#===================================================Code to be used on normalised table ====================================================
# Qn 1 - Generate a list of unique locations (countries) in Asia
SELECT DISTINCT (country) 
FROM location 
WHERE continent = "Asia"
ORDER BY country;
-- 47 rows returned






# Qn 2 - Generate a list of unique locations (countries) in Asia and Europe, with 
# more than 10 total cases on 2020-04-01
SELECT country FROM location
WHERE continent IN ("Asia", "Europe")
AND Location_ID IN (
	SELECT location_ID FROM cases
	WHERE total_cases > 10
	AND `date` = '2020-04-01')
ORDER BY country;
-- 89 rows returned







# Qn 3 - Generate a list of unique locations (countries) in Africa, with 
# less than 10,000 total cases between 2020-04-01 and 2020-04-20 (inclusive)
SELECT DISTINCT(country)
FROM location
WHERE continent = "Africa"
AND Location_ID IN (
	SELECT location_ID FROM cases 
    WHERE total_cases < 10000
	AND `date` BETWEEN '2020-04-01' AND '2020-04-20')
ORDER BY country;
-- 52 rows returned






# Qn 4 - Generate a list of unique locations (countries) without any data on total tests
SELECT DISTINCT(country) FROM location
WHERE location_ID IN (
	SELECT location_ID
	FROM cases
	GROUP BY location_ID
	HAVING SUM(total_tests) = 0)
AND country NOT IN ("World")
ORDER BY country;
-- 121 rows returned






# Qn 5 - Conduct trend analysis, i.e., 
# for each month, compute the total number of new cases globally.
-- Date_format(`date`, "%M %Y")
SELECT CONCAT(YEAR(`date`),'-',LPAD(MONTH(`date`),2,0)) AS `Month`, 
	SUM(new_cases) AS `New Cases`
FROM location l
INNER JOIN cases c
ON l.location_ID = c.location_ID
WHERE country = "World"
GROUP BY MONTH(`date`);
-- 9 rows returned;







# Qn 6 - Conduct trend analysis, i.e.,
# for each month, compute the total number of new cases in each continent
#NA not included as it is not a continent
SELECT l.Continent, CONCAT(YEAR(`date`),'-',LPAD(MONTH(`date`),2,0)) AS `Month`, 
	SUM(new_cases) AS `New Cases`
FROM cases c
INNER JOIN location l
ON c.location_ID = l.location_ID
WHERE continent NOT IN ('NA', '')
GROUP BY continent, MONTH(date)
ORDER BY continent ASC, `date` ASC;
-- 54 rows returned







# Qn 7 - Generate a list of EU countries that have implemented mask related responses
# (i.e., response measure contains the word "mask").
SELECT DISTINCT(l.Country)
FROM response_measures rg 
INNER JOIN location l
ON rg.location_ID = l.location_ID
WHERE continent = "Europe"
AND rg.response_measure LIKE "%mask%"
ORDER BY country;
-- 23 rows returned








# Qn 8 - Compute the period (i.e., start date and end date) in which
# most EU countries has implemented MasksMandatory as the response measure.
# For NA values, use 1-August 2020.
-- update NA values first (ONLY RUN ONCE)
-- UPDATE `response_graphs_2020-08-13`
-- SET date_end = '2020-08-01'
-- WHERE date_end = "NA";
---------------------------------------------

Select t1.date_start, 
	IF(t1.date_end != "NA", t1.date_end, '2020-08-01') AS date_end
FROM response_measures t1
CROSS JOIN response_measures t2
WHERE t1.Response_measure = "MasksMandatory"
AND t2.Response_measure = "MasksMandatory"
GROUP BY t1.date_start, t1.date_end, t1.location_ID
ORDER BY count(
	CASE WHEN t1.date_start >= t2.date_start 
	AND t1.date_start <= IF(t2.date_end != "NA", t2.date_end, '2020-08-01') 
	AND IF(t1.date_end != "NA", t1.date_end, '2020-08-01')  >= t2.date_start
	AND IF(t1.date_end != "NA", t1.date_end, '2020-08-01') 
		<= IF(t2.date_end != "NA", t2.date_end, '2020-08-01') 
	THEN 1 END) DESC LIMIT 1;
-- 27 Jul - 1 Aug 2020










# Qn 9 - Based on the period above, 
# conduct trend analysis for Europe and North America, i.e., 
# for each day during the period, compute the total number of new cases.
SELECT Continent, `date`, SUM(new_cases) as `Total Number of New Cases`
FROM cases c
INNER JOIN location l
ON c.location_ID = l.location_ID 
WHERE continent IN ("Europe", "North America")
AND `date` BETWEEN 
(Select x.date_start from (Select t1.date_start, 
	IF(t1.date_end != "NA", t1.date_end, '2020-08-01') AS date_end
FROM response_measures t1
CROSS JOIN response_measures t2
WHERE t1.Response_measure = "MasksMandatory"
AND t2.Response_measure = "MasksMandatory"
GROUP BY t1.date_start, t1.date_end, t1.location_ID
ORDER BY count(
	CASE WHEN t1.date_start >= t2.date_start 
	AND t1.date_start <= IF(t2.date_end != "NA", t2.date_end, '2020-08-01') 
	AND IF(t1.date_end != "NA", t1.date_end, '2020-08-01')  >= t2.date_start
	AND IF(t1.date_end != "NA", t1.date_end, '2020-08-01') 
		<= IF(t2.date_end != "NA", t2.date_end, '2020-08-01') 
	THEN 1 END) DESC LIMIT 1) x)
AND
(Select y.date_end from (Select t1.date_start, 
	IF(t1.date_end != "NA", t1.date_end, '2020-08-01') AS date_end
FROM response_measures t1
CROSS JOIN response_measures t2
WHERE t1.Response_measure = "MasksMandatory"
AND t2.Response_measure = "MasksMandatory"
GROUP BY t1.date_start, t1.date_end, t1.location_ID
ORDER BY count(
	CASE WHEN t1.date_start >= t2.date_start 
	AND t1.date_start <= IF(t2.date_end != "NA", t2.date_end, '2020-08-01') 
	AND IF(t1.date_end != "NA", t1.date_end, '2020-08-01')  >= t2.date_start
	AND IF(t1.date_end != "NA", t1.date_end, '2020-08-01') 
		<= IF(t2.date_end != "NA", t2.date_end, '2020-08-01') 
	THEN 1 END) DESC LIMIT 1) y)
GROUP BY continent, `date`
ORDER BY continent;
-- 12 rows returned



# Qn 10 - Generate a list of unique locations (countries) that have successfully flattened the curve 
# (i.e., achieved more than 14 days of 0 new cases, after recording more than 50 cases)
SELECT DISTINCT(x.country) 
FROM ( -- to count #consec days with 0 new cases after >50 cases recorded
	SELECT DISTINCT(l.country), 
		(CASE WHEN new_cases = 0 THEN @runtot:= @runtot +1
        ELSE @runtot := 0 END) AS consecdayswith0cases, 
        `date`, new_cases, total_cases
	FROM cases c
	INNER JOIN location l
    ON c.location_ID = l.location_ID
	WHERE total_cases > 50
    ) x
WHERE x.consecdayswith0cases >= 14
AND country NOT IN ("World", "International")
ORDER BY country;
-- 25 rows returned







# Qn 11 - Second wave detection - generate a list of unique locations (countries)
# that have flattened the curve but suffered upticks in new cases 
# (i.e., after >= 14 days, registered more than 50 cases in a subsequent 7-day window)
SELECT DISTINCT(x.country) FROM (
	SELECT DISTINCT(l.country), (CASE WHEN new_cases = 0 
		THEN @runtot :=@runtot + 1
		ELSE @runtot :=0 END) AS runtotal, new_cases, 
    SUM(new_cases) OVER (PARTITION BY c.location_ID 
	ORDER BY `date` ROWS BETWEEN CURRENT ROW AND 6 FOLLOWING) AS weeklysum
	FROM cases c
	INNER JOIN location l
    ON c.location_ID = l.location_ID
	WHERE total_cases > 50 ) x
WHERE x.runtotal >= 14 
AND (country NOT IN ("World"))
AND weeklysum > 50;
-- from the locations in qn 10, count the sum of cases in the next 7 days after 14 days of 0 cases
-- French Polynesia and Equatorial Guinea returned









# Qn 12 - Display the top 3 countries in terms of changes from baseline in each of the place categories 
# (i.e., grocery and pharmacy, parks, transit stations, retail and recreation, residential, and workplaces)
SELECT country, MAX(ABS(grocery_and_pharmacy_percent_change_from_baseline)) 
	AS `Grocery and Pharmacy Baseline Change - Top 3`
FROM mobility_data m
INNER JOIN location l
ON m.location_ID = l.location_ID
GROUP BY country
ORDER BY `Grocery and Pharmacy Baseline Change - Top 3` DESC
LIMIT 3;
-- returns India 454, Poland 343, Germany 332: correct!


SELECT country, MAX(ABS(parks_percent_change_from_baseline)) AS `Parks Baseline Change - Top 3`
FROM mobility_data m
INNER JOIN location l
ON m.location_ID = l.location_ID
GROUP BY country
ORDER BY `Parks Baseline Change - Top 3` DESC
LIMIT 3;
-- returns France 1206, Poland 1187, Italy 1029



(SELECT country, MAX(ABS(transit_stations_percent_change_from_baseline)) AS `Transit Stations Baseline Change - Top 3`
FROM mobility_data m
INNER JOIN location l
ON m.location_ID = l.location_ID
GROUP BY country
ORDER BY `Transit Stations Baseline Change - Top 3` DESC
LIMIT 3);
-- returns India 497, Poland 384, Austria 383




(SELECT country, MAX(ABS(retail_and_recreation_percent_change_from_baseline)) AS `Retail and Recreation Baseline Change - Top 3`
FROM mobility_data m
INNER JOIN location l
ON m.location_ID = l.location_ID
GROUP BY country
ORDER BY `Retail and Recreation Baseline Change - Top 3` DESC
LIMIT 3);
-- returns Poland 545, Turkey 333, India 313 


(SELECT country, MAX(ABS(residential_percent_change_from_baseline)) AS `Residential Baseline Change - Top 3`
FROM mobility_data m
INNER JOIN location l
ON m.location_ID = l.location_ID
GROUP BY country
ORDER BY `Residential Baseline Change - Top 3` DESC
LIMIT 3);
-- returns Peru 57, Ecuador 56, Kuwait 56


(SELECT country, MAX(ABS(workplaces_percent_change_from_baseline)) AS `Workplaces Baseline Change - Top 3`
FROM mobility_data m
INNER JOIN location l
ON m.location_ID = l.location_ID
GROUP BY country
ORDER BY `Workplaces Baseline Change - Top 3` DESC
LIMIT 3);
-- returns India 258, Bulgaria 174, Romania 100






# Qn 13 - Conduct mobility trend analysis, i.e., in Indonesia, identify the date where more than 20,000 cases were recorded (D-day). 
# Based on D-day, show the daily changes in mobility trends for the 3 place categories 
# (i.e., retail and recreation, workplaces, and grocery and pharmacy).
SELECT `date`, ROUND(AVG(retail_and_recreation_percent_change_from_baseline), 3) AS `Retail and Recreation`, 
	ROUND(AVG(workplaces_percent_change_from_baseline), 3) AS `Workplaces`,
    ROUND(AVG(grocery_and_pharmacy_percent_change_from_baseline), 3) AS `Grocery and Pharmacy`
FROM mobility_data m
INNER JOIN location l
ON m.location_ID = l.location_ID
WHERE l.country = "Indonesia"
AND `date` >= (
	SELECT MIN(c.`date`)
	FROM cases c
	WHERE location_ID = (
		SELECT location_ID 
        FROM location 
        WHERE country = "Indonesia" 
        GROUP BY country)
	AND total_cases > 20000)
GROUP BY `date`;
-- 94 rows returned

